function setup_prms()
   setup_prm_file = "setup-qualif1A.prm"
   do_eval = false
   return setup_prm_file,do_eval
end
require("rob1a-run")
