import random


def secret_number_generator():
    # Insert special Snake Corporation sauce here ...
    return random.randint(0, 9999)
