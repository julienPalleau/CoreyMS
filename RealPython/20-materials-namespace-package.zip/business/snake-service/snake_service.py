from snake_corp import dateutil, magic

print(magic.secret_number_generator())
print(dateutil.days_to_snake_day())
