```s
$ python -m venv venv
$ source venv/bin/activate
(venv) $ python -m pip install -e data-repos/
(venv) $ python -m pip install -e snake-corp-product-data/
```

```powershell
PS> python -m venv venv
PS> venv\scripts\activate
(venv) PS> python -m pip install -e "data-repos\"
(venv) PS> python -m pip install -e "snake-corp-product-data\"
```
